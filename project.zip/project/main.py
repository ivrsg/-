import datetime
import sqlite3
import sys

from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication
from PyQt6.QtWidgets import QMainWindow, QFileDialog, QInputDialog, QStatusBar, QTableWidgetItem, \
    QLineEdit, QLabel, QPushButton, QCalendarWidget, QTableWidget, QLCDNumber, QMessageBox

SCREEN_SIZE = [1000, 600]
DAYSWEEK = {0: [0, 6], 1: [1, 5], 2: [2, 4], 3: [3, 3], 4: [4, 2], 5: [5, 1], 6: [6, 0]}


class NumberError(Exception):
    pass


def isnumber(oldnomber):
    newnumber = ''
    if (('-' in oldnomber or ' ' in oldnomber) and '--' not in oldnomber and
            oldnomber[0] != '-' and oldnomber[-1] != '-'):
        for i in oldnomber:
            if i != '-' and i != ' ' and i != '\t':
                newnumber += i
    else:
        for i in oldnomber:
            if i != ' ' and i != '\t':
                newnumber += i
    oldnomber = newnumber[::]
    newnumber = ''
    if ('(' in oldnomber and ')' in oldnomber and oldnomber.index('(') < oldnomber.index(')') and (
            oldnomber.count('(') == 1 and oldnomber.count(')') == 1)
            or oldnomber.count('(') == 0 and oldnomber.count(')') == 0):
        for i in oldnomber:
            if i != ')' and i != '(':
                newnumber += i
    else:
        newnumber = oldnomber[::]
    try:
        if newnumber[0] == '-' or (newnumber[0] != '8' and newnumber[0] != '+') or newnumber[:2] == '+8':
            newnumber += 'aaaaa'
        newnumber = str(int(newnumber))
        if len(newnumber) == 11 and newnumber[0] == '8':
            return newnumber
        elif len(newnumber) == 11 and newnumber[0] == '7':
            return '8' + newnumber[1:]
        raise NumberError()
    except ValueError:
        raise NumberError()
    except IndexError:
        raise NumberError()


class BaseOfKlients(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setGeometry(300, 200, *SCREEN_SIZE)
        self.setFixedSize(*SCREEN_SIZE)
        self.setWindowTitle('Запись клиентов')
        self.setWindowIcon(QIcon("icon.jpg"))
        self.fname = ''
        self.label_surname = QLabel('Фамилия', self)
        self.label_surname.resize(51, 13)
        self.label_surname.move(30, 20)

        self.surname = QLineEdit(self)
        self.surname.resize(131, 16)
        self.surname.move(30, 40)

        self.label_name = QLabel('Имя', self)
        self.label_name.resize(47, 13)
        self.label_name.move(30, 60)

        self.name = QLineEdit(self)
        self.name.resize(131, 16)
        self.name.move(30, 80)

        self.label_midname = QLabel('Отчество (Не обязательно)', self)
        self.label_midname.resize(151, 13)
        self.label_midname.move(30, 100)

        self.middlename = QLineEdit(self)
        self.middlename.resize(131, 16)
        self.middlename.move(30, 120)

        self.label_date = QLabel('Дата', self)
        self.label_date.resize(47, 13)
        self.label_date.move(30, 140)

        self.date = QLineEdit(self)
        self.date.resize(131, 16)
        self.date.move(30, 160)

        self.label_number = QLabel('Номер', self)
        self.label_number.resize(47, 13)
        self.label_number.move(30, 180)

        self.number = QLineEdit(self)
        self.number.resize(131, 16)
        self.number.move(30, 200)

        self.label_service = QLabel('Услуга', self)
        self.label_service.resize(47, 13)
        self.label_service.move(30, 220)

        self.service = QLineEdit(self)
        self.service.resize(131, 16)
        self.service.move(30, 240)

        self.label_price = QLabel('Цена услуги (р)', self)
        self.label_price.resize(111, 16)
        self.label_price.move(30, 260)

        self.price = QLineEdit(self)
        self.price.resize(131, 16)
        self.price.move(30, 280)

        self.label_file = QLabel('Файл', self)
        self.label_file.resize(47, 13)
        self.label_file.move(30, 297)

        self.label_klient = QLabel('Клиент', self)
        self.label_klient.resize(47, 13)
        self.label_klient.move(30, 357)

        self.label_serv = QLabel('Услуга и её цена', self)
        self.label_serv.resize(120, 13)
        self.label_serv.move(30, 392)

        self.open = QPushButton('Открыть', self)
        self.open.resize(131, 23)
        self.open.move(30, 310)

        self.addKlient = QPushButton('Добавить клиента', self)
        self.addKlient.resize(131, 23)
        self.addKlient.move(30, 370)

        self.deliteKlient = QPushButton('Удалить клиента', self)
        self.deliteKlient.resize(131, 23)
        self.deliteKlient.move(160, 370)

        self.addService = QPushButton('Добавить услугу', self)
        self.addService.resize(131, 23)
        self.addService.move(100, 405)

        self.deliteService = QPushButton('Удалить услугу', self)
        self.deliteService.resize(131, 23)
        self.deliteService.move(30, 430)

        self.changePrice = QPushButton('Изменить цену', self)
        self.changePrice.resize(131, 23)
        self.changePrice.move(160, 430)

        self.newbase = QPushButton('Создать', self)
        self.newbase.resize(131, 23)
        self.newbase.move(160, 310)

        self.closebtn = QPushButton('Закрыть', self)
        self.closebtn.resize(131, 23)
        self.closebtn.move(100, 335)

        self.AddorDelKlient = QPushButton('Добавить', self)
        self.AddorDelKlient.resize(111, 23)
        self.AddorDelKlient.move(170, 220)

        self.AddorDelService = QPushButton('Добавить', self)
        self.AddorDelService.resize(111, 23)
        self.AddorDelService.move(170, 280)

        self.calendarWidget = QCalendarWidget(self)
        self.calendarWidget.resize(321, 201)
        self.calendarWidget.move(300, 10)

        self.tableWidget = QTableWidget(self)
        self.tableWidget.resize(681, 311)
        self.tableWidget.move(300, 240)

        self.label_profitDay = QLabel('Ожидаемая прибыль за день:', self)
        self.label_profitDay.resize(181, 20)
        self.label_profitDay.move(630, 20)

        self.label_price = QLabel('Ожидаемая прибыль за неделю:', self)
        self.label_price.resize(181, 20)
        self.label_price.move(630, 50)

        self.label_price = QLabel('Ожидаемая прибыль за месяц:', self)
        self.label_price.resize(181, 20)
        self.label_price.move(630, 80)

        self.profitDay = QLCDNumber(self)
        self.profitDay.resize(121, 21)
        self.profitDay.move(820, 20)

        self.profitWeek = QLCDNumber(self)
        self.profitWeek.resize(121, 21)
        self.profitWeek.move(820, 50)

        self.profitMonth = QLCDNumber(self)
        self.profitMonth.resize(121, 21)
        self.profitMonth.move(820, 80)

        self.statusBar = QStatusBar(self)
        self.statusBar.move(10, 560)
        self.statusBar.resize(1000, 20)
        self.initUI()

    def initUI(self):
        self.hideklient()
        self.hideservise()
        self.AddorDelKlient.hide()
        self.AddorDelService.hide()
        self.open.clicked.connect(self.openFile)
        self.newbase.clicked.connect(self.newFile)
        self.addKlient.clicked.connect(self.klient)
        self.deliteKlient.clicked.connect(self.klient)
        self.AddorDelKlient.clicked.connect(self.changeBaseKlient)
        self.addService.clicked.connect(self.servicebtn)
        self.deliteService.clicked.connect(self.servicebtn)
        self.changePrice.clicked.connect(self.servicebtn)
        self.AddorDelService.clicked.connect(self.changeBaseService)
        self.closebtn.clicked.connect(self.closeFile)
        self.calendarWidget.clicked.connect(self.datePlans)
        self.datePlans()

    def openFile(self):
        self.fname = QFileDialog.getOpenFileName(self, 'Выбрать базу клиентов', '',
                                                 'База клиентов (*.sqlite *.db *.sdb *.db3 *.s3db *.sqlite3 *.sl3)')[0]
        if self.fname != '':
            self.statusBar.clearMessage()
            self.datePlans()
        else:
            self.hideklient()
            self.hideservise()
            self.datePlans()
            self.hidefinances()
            self.tableWidget.setRowCount(0)

    def newFile(self):
        name, ok_pressed = QInputDialog.getText(self, 'Введите имя файла', 'Имя файла')
        if ok_pressed:
            try:
                self.statusBar.clearMessage()
                con = sqlite3.connect(name + '.sqlite')
                cur = con.cursor()
                cur.execute("""CREATE TABLE klients (
                id         INTEGER PRIMARY KEY AUTOINCREMENT
                           UNIQUE
                           NOT NULL,
                klient     STRING  NOT NULL,
                date       TEXT    NOT NULL,
                number     STRING  NOT NULL ON CONFLICT ROLLBACK,
                service_id INTEGER NOT NULL
                );""")
                cur.execute("""CREATE TABLE services (
                id      INTEGER PRIMARY KEY AUTOINCREMENT
                        UNIQUE
                        NOT NULL,
                service STRING  NOT NULL
                        UNIQUE,
                price   INTEGER NOT NULL
                );""")
                con.commit()
                con.close()
            except sqlite3.OperationalError:
                self.statusBar.showMessage('Файл с таким именем уже существует')

    def closeFile(self):
        if self.fname != '':
            self.fname = ''
            self.hideklient()
            self.hideservise()
            self.datePlans()
            self.hidefinances()
        else:
            self.statusBar.showMessage('Файл не открыт')

    def hideklient(self):
        self.surname.setText('')
        self.name.setText('')
        self.middlename.setText('')
        self.date.setText('')
        self.number.setText('')
        self.service.setText('')
        self.surname.setReadOnly(True)
        self.name.setReadOnly(True)
        self.middlename.setReadOnly(True)
        self.date.setReadOnly(True)
        self.number.setReadOnly(True)
        self.service.setReadOnly(True)
        self.AddorDelKlient.hide()

    def hideservise(self):
        self.service.setText('')
        self.price.setText('')
        self.service.setReadOnly(True)
        self.price.setReadOnly(True)
        self.AddorDelService.hide()

    def hidefinances(self):
        self.profitDay.display(0)
        self.profitWeek.display(0)
        self.profitMonth.display(0)

    def klient(self):
        self.statusBar.clearMessage()
        if self.fname != '':
            self.hideklient()
            self.hideservise()
            self.surname.setReadOnly(False)
            self.name.setReadOnly(False)
            self.middlename.setReadOnly(False)
            self.date.setReadOnly(False)
            self.number.setReadOnly(False)
            self.service.setReadOnly(False)
            self.AddorDelKlient.show()
            if self.sender().text() == 'Добавить клиента':
                self.AddorDelKlient.setText('Добавить')
            else:
                self.AddorDelKlient.setText('Удалить')
        else:
            self.statusBar.showMessage('Файл не открыт')

    def changeBaseKlient(self):
        self.statusBar.clearMessage()
        con = sqlite3.connect(self.fname)
        cur = con.cursor()
        service = None
        name = ''
        if self.middlename.text() != '' and self.surname.text() != '' and self.name.text() != '':
            name = self.surname.text() + ' ' + self.name.text() + ' ' + self.middlename.text()
        elif self.surname.text() != '' and self.name.text() != '':
            name = self.surname.text() + ' ' + self.name.text()
        date = self.date.text()
        try:
            date = str(datetime.datetime.strptime(date, '%d.%m.%Y')).split('-')
            date = date[2][:2] + '.' + date[1] + '.' + date[0]
            number = isnumber(self.number.text())
            service = cur.execute('''SELECT id FROM services WHERE service = ?''',
                                  (self.service.text(),)).fetchone()
            if name != '' and date != '' and number != '' and service != '':
                if self.AddorDelKlient.text() == 'Добавить':
                    if datetime.datetime.strptime(date, '%d.%m.%Y') < datetime.datetime.strptime(
                            str(datetime.datetime.now().date()), '%Y-%m-%d'):
                        valid = QMessageBox.question(
                            self, 'Подтвердите',
                            "Вы точно хотите добавить клиентана на прошедшее число?",
                            buttons=QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                        if valid == QMessageBox.StandardButton.Yes:
                            cur.execute("""INSERT INTO klients(klient, date, number, service_id) VALUES(?, ?, ?, ?)""",
                                        (name, date, number, service[0]))
                    else:
                        cur.execute("""INSERT INTO klients(klient, date, number, service_id) VALUES(?, ?, ?, ?)""",
                                    (name, date, number, service[0]))
                else:
                    idklient = cur.execute("""SELECT id FROM klients
                                WHERE klient=? AND date=? AND number=? AND service_id=?""",
                                           (name, date, number, service[0])).fetchone()
                    valid = QMessageBox.question(
                        self, 'Подтвердите', "Вы действительно хотите удалить клиента с id " + str(idklient[0]) + '?',
                        buttons=QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                    if valid == QMessageBox.StandardButton.Yes:
                        cur.execute("""DELETE from klients where id=?""", (idklient[0],))
                con.commit()
                self.hideklient()
                self.datePlans()
                con.close()
            else:
                self.statusBar.showMessage('Введены не все данные')
        except TypeError:
            if service:
                self.statusBar.showMessage('Клиента с введенными данными не найдено')
            else:
                self.statusBar.showMessage('Услуга не найдена')
        except NumberError:
            self.statusBar.showMessage('Неверный формат номера')
        except ValueError:
            self.statusBar.showMessage('Неверный формат даты (нужен dd.mm.yyyy) либо несуществующая дата')

    def servicebtn(self):
        self.statusBar.clearMessage()
        if self.fname != '':
            self.hideklient()
            self.hideservise()
            self.service.setReadOnly(False)
            self.price.setReadOnly(False)
            self.AddorDelService.show()
            if self.sender().text() == 'Добавить услугу':
                self.AddorDelService.setText('Добавить')
            elif self.sender().text() == 'Изменить цену':
                self.AddorDelService.setText('Изменить')
            else:
                self.price.setReadOnly(True)
                self.AddorDelService.setText('Удалить')
        else:
            self.statusBar.showMessage('Файл не открыт')

    def changeBaseService(self):
        self.statusBar.clearMessage()
        if self.fname != '':
            con = sqlite3.connect(self.fname)
            cur = con.cursor()
            service = self.service.text()
            if service == '':
                self.statusBar.showMessage('Введите услугу ;)')
            else:
                try:
                    idservice = cur.execute("""SELECT id FROM services WHERE service=?""",
                                            (service,)).fetchone()
                    if self.AddorDelService.text() == 'Удалить':
                        valid = QMessageBox.question(
                            self, 'Подтвердите', "Вы действительно хотите удалить услугу с id " + str(
                                idservice[0]) + ' и клиентов с этой услугой?',
                            buttons=QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                        if valid == QMessageBox.StandardButton.Yes:
                            cur.execute("""DELETE from services where id=?""", (idservice[0],))
                            if len(cur.execute("""SELECT id FROM klients WHERE service_id=?""",
                                               (idservice[0],)).fetchall()) > 0:
                                cur.execute("""DELETE from klients where service_id=?""", (idservice[0],))
                            con.commit()
                            self.hideservise()
                            self.datePlans()
                            con.close()
                    else:
                        price = int(self.price.text())
                        if self.AddorDelService.text() == 'Добавить':
                            cur.execute("""INSERT INTO services(service, price) VALUES(?, ?)""",
                                        (service, price))
                        elif self.AddorDelService.text() == 'Изменить':
                            valid = QMessageBox.question(
                                self, 'Подтвердите',
                                "Вы действительно хотите изменить цену услеге с id " + str(idservice[0]) + '?',
                                buttons=QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                            if valid == QMessageBox.StandardButton.Yes:
                                cur.execute("""UPDATE services SET price=? WHERE id=?""",
                                            (price, idservice[0]))
                        con.commit()
                        self.hideservise()
                        self.datePlans()
                        con.close()
                except sqlite3.IntegrityError:
                    self.statusBar.showMessage('Услуга с таким именем уже существует')
                except ValueError:
                    self.statusBar.showMessage('Неверный формат цены')
                except TypeError:
                    self.statusBar.showMessage('Услуга не найдена')
        else:
            self.statusBar.showMessage('Файл не открыт')

    def datePlans(self):
        self.statusBar.clearMessage()
        if self.fname != '':
            try:
                date = self.calendarWidget.selectedDate().toString("dd.MM.yyyy")
                con = sqlite3.connect(self.fname)
                cur = con.cursor()
                day_plans = cur.execute("""SELECT * FROM klients WHERE date=?""",
                                        (date,)).fetchall()
                self.tableWidget.setRowCount(len(day_plans))
                service_plans1 = list(
                    cur.execute("""SELECT service_id FROM klients WHERE date=?""",
                                (date,)).fetchall())
                money_plans1 = []
                namesservices = []
                for service in service_plans1:
                    money_plans1.append(
                        cur.execute("""SELECT price FROM services WHERE id=?""",
                                    (service[0],)).fetchone()[0])
                    namesservices.append(
                        cur.execute("""SELECT service FROM services WHERE id=?""",
                                    (service[0],)).fetchone()[0])
                service_plans2 = []
                money_plans2 = []
                datedt = datetime.datetime.strptime(date, '%d.%m.%Y')
                dateweekday = DAYSWEEK[datedt.date().weekday()]
                for daymin in range(1, dateweekday[0] + 1):
                    datedtdel = datetime.timedelta(days=daymin)
                    weekdate = str(datedt - datedtdel).split('-')
                    weekdate = weekdate[2][:2] + '.' + weekdate[1] + '.' + weekdate[0]
                    service_plans2 += list(
                        cur.execute("""SELECT service_id FROM klients WHERE date=?""",
                                    (weekdate,)).fetchall())
                for dayplus in range(1, dateweekday[1] + 1):
                    datedtdel = datetime.timedelta(days=dayplus)
                    weekdate = str(datedt + datedtdel).split('-')
                    weekdate = weekdate[2][:2] + '.' + weekdate[1] + '.' + weekdate[0]
                    service_plans2 += list(
                        cur.execute("""SELECT service_id FROM klients WHERE date=?""",
                                    (weekdate,)).fetchall())
                for service in service_plans2:
                    money_plans2.append(
                        cur.execute("""SELECT price FROM services WHERE id=?""",
                                    (service[0],)).fetchone()[0])
                service_plans3 = []
                money_plans3 = []
                for day in range(1, 32):
                    if len(str(day)) == 1:
                        day = '0' + str(day)
                    else:
                        day = str(day)
                    monthdate = day + date[2:]
                    service_plans3 += list(
                        cur.execute("""SELECT service_id FROM klients WHERE date=?""",
                                    (monthdate,)).fetchall())
                for service in service_plans3:
                    money_plans3.append(
                        cur.execute("""SELECT price FROM services WHERE id=?""",
                                    (service[0],)).fetchone()[0])
                self.profitDay.display(sum(money_plans1))
                self.profitWeek.display(sum(money_plans2) + sum(money_plans1))
                self.profitMonth.display(sum(money_plans3))

                if not day_plans:
                    self.statusBar.showMessage('Работы не запланированно')
                    return
                self.tableWidget.setColumnCount(len(day_plans[0]))
                self.tableWidget.setHorizontalHeaderLabels(['id', 'klient', 'date', 'number', 'service'])
                for row, elem in enumerate(day_plans):
                    for col, val in enumerate(list(elem)[:-1] + [namesservices[row]]):
                        self.tableWidget.setItem(row, col, QTableWidgetItem(str(val)))
                        self.tableWidget.resizeRowToContents(row)
                        self.tableWidget.resizeColumnsToContents()
            except sqlite3.OperationalError:
                self.closeFile()
                self.statusBar.showMessage('Неверная база данных. База аварийно закрыта')
        else:
            self.tableWidget.setRowCount(0)
            self.tableWidget.setColumnCount(0)
            self.statusBar.showMessage('Файл не открыт')


def oshibka(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = BaseOfKlients()
    ex.show()
    sys.excepthook = oshibka
    sys.exit(app.exec())
